var express = require('express')
  , router = express.Router()
  , bodyParser = require('body-parser')
  , models = require('../models');

var jsonParser = bodyParser.json({ type: 'application/json' });

router.post('/contacts', jsonParser , function (req, res) {
  if(!req.body || req.body.length === 0) {
    console.log('request body not found');
    return res.sendStatus(400);
  }
  var user = req.body;
  console.log('request body : ' + JSON.stringify(user));
  models.Contact.create({
    id:req.body.id,
    first_name: "first_name",
    last_name: req.body.last_name,
    mobile_no: req.body.mobile_no,
    email: req.body.email
  }).then(function (contacts) {
    res.json(contacts);
  });
  });

// get all contacts
router.get('/allcontacts', function (req, res) {
  console.log("code in /allcontacts");
  models.Contact.findAll({}).then(function (contacts) {
    res.json(contacts);
  });
});

// get single contact
router.get('/contacts/:id', function (req, res) {
  models.Contact.find({
    where: {
      id: req.params.id
    }
  }).then(function (contacts) {
    res.json(contacts);
  });
});

// delete a single contact
router.delete('/contacts/:id', function (req, res) {
  models.Contact.destroy({
    where: {
      id: req.params.id
    }
  }).then(function (contacts) {
    res.json(contacts);
  });
});

// update single contact
router.put('/contacts/:id', function (req, res) {
  models.Contact.find({
    where: {
      id: req.params.id
    }
  }).then(function (contacts) {
    if (contacts) {
      todo.updateAttributes({
        first_name: req.body.first_name,
        last_name: req.body.last_name
      }).then(function (contacts) {
        res.send(contacts);
      });
    }
  });
});



module.exports = router